<h4 class="toggle-header">
	<?php
	$post_title = !empty( $the_name ) ? esc_html( $the_name ) : get_the_title();

	if( ! empty( $the_link ) ){
    	echo '<cite><a href="'.esc_url( $the_link ).'" title="'.esc_attr( $post_title ).'">'.$post_title.'</a></cite>';
	} else {
    	echo $post_title;
	}?>	
	<span class="aux-accordion-indicator"></span>
</h4>
<div class="toggle-content">
	<?php
		echo the_content();
    ?>
    <!-- clear the floated elements at the end of content -->
    <div class="clear"></div>
</div>