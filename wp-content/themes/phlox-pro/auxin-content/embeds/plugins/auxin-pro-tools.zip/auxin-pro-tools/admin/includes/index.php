<?php // load admin related classes & functions

// load admin related functions
include_once( 'admin-the-functions.php' );

// load admin related classes
include_once( 'classes/class-auxpro-admin-assets.php'  );

do_action( 'auxpro_admin_classes_loaded' );

// load metaboxes here

// load admin related functions
include_once( 'admin-hooks.php' );

// load config for 'Element Pack' plugin
include_once( 'modules/element-pack-config.php' );
